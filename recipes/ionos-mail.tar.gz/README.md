# IONOS Webmail for Franz and Ferdi
This repository hosts the [IONOS Webmail](https://mail.ionos.de/) Recipe for [Franz](https://meetfranz.com/).